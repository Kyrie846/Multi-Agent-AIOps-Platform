# Cassandra compaction executor blocked tasks (Instaclustr)

> Group: **Databases**  
> Service: **Cassandra**  
> Exporter: `instaclustr-cassandra-exporter`  
> Severity: **warning**  
> Duration (for): `2m`

## 现象 / Description

Some Cassandra compaction executor tasks are blocked - {{ $labels.cassandra_cluster }}

## PromQL 查询

```promql
cassandra_thread_pool_blocked_tasks{pool="CompactionExecutor"} > 15
```

## 故障定位

- 触发该告警时, 检查 Cassandra 的相关指标和日志
- 严重等级: warning
- 来源: awesome-prometheus-alerts / Databases / Cassandra
